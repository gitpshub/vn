'use client'

import { useState, useEffect } from 'react'
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Mic, MicOff, Send } from 'lucide-react'
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip"

export default function SpeechRecognitionApp() {
  const [text, setText] = useState('')
  const [isListening, setIsListening] = useState(false)
  const [recognition, setRecognition] = useState<SpeechRecognition | null>(null)

  useEffect(() => {
    if (typeof window !== 'undefined' && 'SpeechRecognition' in window || 'webkitSpeechRecognition' in window) {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition
      const recognitionInstance = new SpeechRecognition()
      recognitionInstance.continuous = true
      recognitionInstance.interimResults = true

      recognitionInstance.onresult = (event) => {
        const transcript = Array.from(event.results)
          .map(result => result[0])
          .map(result => result.transcript)
          .join('')

        setText(transcript)
      }

      recognitionInstance.onerror = (event) => {
        console.error('Speech recognition error', event.error)
        setIsListening(false)
      }

      recognitionInstance.onend = () => {
        setIsListening(false)
      }

      setRecognition(recognitionInstance)
    } else {
      console.error('Speech recognition not supported')
    }
  }, [])

  const toggleListening = () => {
    if (isListening) {
      recognition?.stop()
    } else {
      recognition?.start()
    }
    setIsListening(!isListening)
  }

  const sendText = async () => {
    if (text && !isListening) {
      try {
        const response = await fetch('https://api.example.com/endpoint', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ text }),
        })
        if (response.ok) {
          console.log('Text sent successfully')
          setText('')
        } else {
          console.error('Failed to send text')
        }
      } catch (error) {
        console.error('Error sending text:', error)
      }
    }
  }

  return (
    <TooltipProvider>
      <div className="flex flex-col items-center justify-center w-full">
        <div className="w-full max-w-md space-y-4">
          <Textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder="Dictated text will appear here"
            className={`w-full p-2 border rounded min-h-[150px] ${isListening ? 'border-blue-500 shadow-md' : ''}`}
          />
          <div className="flex justify-between">
            <Tooltip>
              <TooltipTrigger asChild>
                <Button 
                  onClick={toggleListening} 
                  className={`w-1/2 mr-2 ${isListening ? 'bg-blue-500 hover:bg-blue-600' : ''}`}
                >
                  {isListening ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>{isListening ? 'Stop Dictation' : 'Start Dictation'}</p>
              </TooltipContent>
            </Tooltip>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button 
                  onClick={sendText} 
                  className="w-1/2 ml-2" 
                  disabled={isListening || !text}
                >
                  <Send className="w-5 h-5" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>Send Text</p>
              </TooltipContent>
            </Tooltip>
          </div>
        </div>
      </div>
    </TooltipProvider>
  )
}

